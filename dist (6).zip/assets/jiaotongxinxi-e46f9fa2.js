const s="/assets/icon38-4c5525e3.png",o="/assets/jiaotongxinxi-db9473ba.png";export{s as _,o as a};
