const s="/assets/cheliangdj-abb1d1bb.png";export{s as _};
