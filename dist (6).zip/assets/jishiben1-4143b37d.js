const s="/assets/jishiben1-f4eb55a6.png";export{s as _};
