import{r as t}from"./request-0eebb2e7.js";function o(){return t({url:"/GPSdevice/get",method:"get"})}function a(e){return t({url:"/GPS/get",method:"get",params:e})}export{a,o as g};
