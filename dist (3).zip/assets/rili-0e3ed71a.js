const s="/assets/rili-26f284a2.png";export{s as _};
